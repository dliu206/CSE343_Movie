//
// Created by david on 2/14/2020.
//

#ifndef ASS4_MOVIEDB_H
#define ASS4_MOVIEDB_H
#include "MovieHeadNode.h"

class MovieDB {
    friend ostream &operator<<(ostream &Out, const MovieDB &M);
public:
    MovieDB();
    ~MovieDB();

    MovieHeadNode* funnyRoot;
    MovieHeadNode* dramaRoot;
    MovieHeadNode* classicRoot;

    void insert(string op, MovieHeadNode*& target);
    bool retrieve(string op, string director, MovieHeadNode*& pos);
    bool classicRetrieve(string year, string majorActor, MovieHeadNode*& pos);
    void display() const;
private:
    void deleteHelper(MovieHeadNode& curr);
    void insertHelper(MovieHeadNode& curr, MovieHeadNode*& target);
    void displayHelper(MovieHeadNode* curr) const;
    bool classicRetrieveHelper(string year, string majorActor, MovieHeadNode* curr, MovieHeadNode*& pos);



};


#endif //ASS4_MOVIEDB_H
