#include <iostream>
#include "MovieNode.h"
#include "ClassicNode.h"
#include "MovieDB.h"
#include <fstream>
#include <unordered_map>
#include "User.h"
#include "HashTable.h"
#include "Classic.h"
#include "Comedy.h"
#include "Drama.h"

using namespace std;

int main() {

    MovieDB movieDb;

    ifstream infile("data4movies.txt");
    if (!infile) {
        cout << "File couldn't be opened" << endl;
        return 0;
    }
    string s;
    for (;;) {
        getline(infile, s);
        if (s.length() == 0) {
            break;
        }

        string temp[6];
        for (int a = 0; a < 5; a++) {
            int index = s.find(", ");
            temp[a] = s.substr(0, index);
            s = s.substr(index + 2, s.length() - index);
        }

        string t = temp[4];
        int num = 0;
        int count = 0;
        for (int b = 0; b < 2; b++) {
            num = t.find(' ');
            t = t.substr(num + 1, t.length() - num);
            count += num;
        }
        temp[4] = temp[4].substr(0, count + 1);
        temp[5] = t;

        // D and F
        // 0 -> Op, 1 -> Stock, 2 -> Director, 3 -> Title, 4 -> Year
        // C
        // 0 -> Op, 1 -> Stock, 2 -> Director, 3 -> Title, 4 -> Major Actor, 5 -> Year
        // retrieve has not been checked but i like it
        if (temp[0] == "C" || temp[0] == "F" || temp[0] == "D") {

            MovieHeadNode* headNode = new MovieHeadNode;
            if (temp[0] == "C") {
                if (movieDb.retrieve(temp[0], temp[2], headNode)) {
                    MovieNode* m = new MovieNode;
                    // don't know if this is true
                    if (headNode->retrieve(temp[5], temp[5], temp[4], m)) {
                        m->stock += stoi(temp[1]);
                    } else {
                        ClassicNode* c2 = new ClassicNode;
                        c2->setAttributes(temp[3], temp[5], stoi(temp[1]));
                        c2->setAttribute(temp[4]);
                        m = c2;
                        headNode->insert(m);
                    }
                } else {
                    headNode = nullptr;
                    Classic* c = new Classic;

                    c->setAttributes(temp[2], 0);

                    MovieNode* m = new MovieNode;
                    ClassicNode* c2 = new ClassicNode;
                    c2->setAttributes(temp[3], temp[5], stoi(temp[1]));
                    c2->setAttribute(temp[4]);
//                    cout << c2->title << endl;
                    m = c2;

                    headNode = c;
                    headNode->insert(m);

                    movieDb.insert(temp[0], headNode);
                }
            } else if (temp[0] == "F") {
                // D and F
                // 0 -> Op, 1 -> Stock, 2 -> Director, 3 -> Title, 4 -> Year
                if (movieDb.retrieve(temp[0], temp[2], headNode)) {
                    MovieNode* m = new MovieNode;

                    if (headNode->retrieve(temp[3], temp[4], "", m)) {
                        m->stock += stoi(temp[1]);
                    } else {
                        m->setAttributes(temp[3], temp[4], stoi(temp[1]));
                        headNode->insert(m);
                    }
                } else {
                    Comedy* c = new Comedy;
                    c->setAttributes(temp[2], 0);

                    MovieNode* m = new MovieNode;
                    m->setAttributes(temp[3], temp[4], stoi(temp[1]));

                    headNode = c;
                    headNode->insert(m);

                    movieDb.insert(temp[0], headNode);
                }

            } else if (temp[0] == "D") {
                if (movieDb.retrieve(temp[0], temp[2], headNode)) {
                    MovieNode* m = new MovieNode;

                    if (headNode->retrieve(temp[3], temp[4], "", m)) {
                        m->stock += stoi(temp[1]);
                    } else {
                        m->setAttributes(temp[3], temp[4], stoi(temp[1]));
                        headNode->insert(m);
                    }
                } else {
                    Drama* d = new Drama;
                    d->setAttributes(temp[2], 0);

                    MovieNode* m = new MovieNode;
                    m->setAttributes(temp[3], temp[4], stoi(temp[1]));

                    headNode = d;
                    headNode->insert(m);

                    movieDb.insert(temp[0], headNode);
                }
            }
        } else {
            cout << "Incorrect Operator - Must Be (C) Classic / (F) Funny / (D) Drama" << endl;
        }

        if (infile.eof()) {
            return 0;
        }
    }
//    movieDb.display();

    HashTable table;
    table.build("data4customers.txt");
//    table.display();


    ifstream infile2("data4commands.txt");
    for(;;) {
        getline(infile2, s);
        if (s.length() == 0) {
            break;
        }
//        cout << s << endl;

        string op = s.substr(0, 1);
        if (op == "I") {
//            movieDb.display();
        } else if (op == "H") {
//            s = s.substr(2, s.length() - 2);
//            int id;
//            try {
//                id = stoi(s);
//            } catch (...) {
//                cout << "Invalid id" << endl;
//                continue;
//            }
//            User* u;
//            if (table.retrieve(id, u)) {
//                u->display();
//            } else {
//                cout << "User does not exist" << endl;
//            }
        } else if (op == "B" || op == "R") {
            s = s.substr(2, s.length() - 2);
            string idString = s.substr(0, s.find(" "));
            int id;
            try {
                id = stoi(idString);
            } catch (...) {
                cout << "Invalid id" << endl;
                continue;
            }
            s = s.substr(s.find(" ") + 1, s.length() - s.find(" "));

            string media = s.substr(0, 1);
            if (media != "D") {
                cout << "Media not supported" << endl;
                continue;
            }
//            cout << media << endl;

            s = s.substr(2, s.length() - 2);
            string type = s.substr(0, 1);
            s = s.substr(2, s.length() - 2);
//            cout << s << endl;
            if (type == "C") {
                string year = s.substr(0, s.find(" "));
                s = s.substr(s.find(" ") + 1, s.length() - s.find(" "));
                year += " ";
                year += s.substr(0, s.find(" "));
                string majorActor = s.substr(s.find(" ") + 1, s.length() - s.find(" "));

                MovieHeadNode* movieHeadNode;
                MovieNode* m;
                if (movieDb.classicRetrieve(year, majorActor, movieHeadNode)) {
                    movieHeadNode->retrieve("", year, majorActor, m);
                    if (op == "B" && m->stock <= 0) {
                        cout << "Not enough stock for this movie" << endl;
                    } else if (op == "B") {
                        User* u;
                        if (table.retrieve(id, u)) {
                            m->stock--;
                            movieHeadNode->totalStock--;
                            string history = "Borrowed Movie";
                            history += m->to_string();
                            u->insertHistory(history);
                        } else {
                            cout << "User does not exist" << endl;
                        }
                    } else if (op == "R") {
                        User* u;
                        if (table.retrieve(id, u)) {
                            m->stock++;
                            movieHeadNode->totalStock++;
                            string history = "Returned Movie";
                            history += m->to_string();
                            u->insertHistory(history);
                        } else {
                            cout << "User does not exist" << endl;
                        }
                    }
                } else {
                    cout << "Movie does not exist" << endl;
                }
            } else if (type == "D") {
//                string director = s.substr(0, s.find(","));
//                string title = s.substr(s.find(", ") + 2, s.length() - s.find(", ") - 2);
//                cout << director << endl;
//                cout << title << endl;
                //comma separated director then title
            } else if (type == "F") {
                // comma separated title then year
            }
        } else {
            cout << "Incorrect command" << endl;
        }
        if (infile2.eof()) {
            break;
        }
    }




    return 0;
}